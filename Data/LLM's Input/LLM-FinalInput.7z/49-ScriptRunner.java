package com.haxademic.core.system.shell;

import java.io.IOException;
import java.util.Arrays;
import java.util.stream.Stream;

import com.haxademic.core.app.P;
import com.haxademic.core.file.FileUtil;
import com.haxademic.core.system.SystemUtil;

public class ScriptRunner {
	
	protected IScriptCallback delegate;
	protected String scriptName;

	public ScriptRunner(String scriptName, IScriptCallback delegate) {
		this.scriptName = scriptName;
		this.scriptName += (SystemUtil.isOSX() == true) ? ".sh" : ".cmd";
		this.delegate = delegate;
	}
	
	public void runWithParams(Object ...args) {
		// create string args array
		String[] argz = new String[args.length];
		for (int i = 0; i < argz.length; i++) {
			argz[i] = (String) args[i];
		}
		
		// run script
		try {
			runScript(argz);
		} catch (InterruptedException e) {
			e.printStackTrace();
			P.out("Script failed (InterruptedException)");
		}		
	}
	
	protected void runScript(String[] args) throws InterruptedException {
		String scriptPath = FileUtil.getScript(scriptName);
		String[] command;
		if(SystemUtil.isOSX()) { 
			command = new String[]{"/bin/sh", "-c", scriptPath + " " + String.join(" ", args)};				// spaces in between args
		} else {
			command = new String[]{"cmd.exe", "/C", scriptPath};
//			<start>
			command =  Stream.concat(Arrays.stream(a), Arrays.stream(b));	// concat arrays via https://stackoverflow.com/a/23188881
//			<end>

		}
	}

}
