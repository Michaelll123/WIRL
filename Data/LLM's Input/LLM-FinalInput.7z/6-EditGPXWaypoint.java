/*
 * Copyright (c) 2014ff Thomas Feuster
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package tf.gpx.edit.values;

import com.hs.gpxparser.modal.Link;
import com.hs.gpxparser.type.Fix;
import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Base64;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.control.skin.ComboBoxListViewSkin;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.WindowEvent;
import javafx.util.StringConverter;
import jfxtras.labs.scene.control.BigDecimalField;
import jfxtras.scene.control.CalendarTextField;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import tf.gpx.edit.helper.AbstractStage;
import static tf.gpx.edit.helper.AbstractStage.INSET_SMALL;
import tf.gpx.edit.helper.LatLongHelper;
import tf.gpx.edit.items.GPXLineItem;
import tf.gpx.edit.items.GPXWaypoint;
import tf.gpx.edit.main.GPXEditor;
import tf.gpx.edit.viewer.MarkerManager;
import tf.helper.general.ObjectsHelper;
import tf.helper.javafx.RestrictiveTextField;
import tf.helper.javafx.TooltipHelper;

/**
 *
 * @author thomas
 */
public class EditGPXWaypoint extends AbstractStage {
    // this is a singleton for everyones use
    // http://www.javaworld.com/article/2073352/core-java/simply-singleton.html
    private final static EditGPXWaypoint INSTANCE = new EditGPXWaypoint();
    
    private final static String MULTIPLE_VALUES = "<Multiple>";

    private GPXEditor myGPXEditor;
    
    // UI elements used in various methods need to be class-wide
    private final TextField waypointNameTxt = new TextField();
    private final TextField waypointDescriptionTxt = new TextField();
    private final TextField waypointCommentTxt = new TextField();
    private final TextField waypointSrcTxt = new TextField();
    private final ComboBox<Label> waypointSymTxt = new ComboBox<>();
    private final TextField waypointTypeTxt = new TextField();
    private final CalendarTextField waypointTimeTxt = new CalendarTextField();
    private LinkTable waypointLinkTable;
    private final RestrictiveTextField waypointLatitudeTxt = new RestrictiveTextField();
    private final RestrictiveTextField waypointLongitudeTxt = new RestrictiveTextField();
    private final BigDecimalField waypointElevationTxt = new BigDecimalField();
    private final BigDecimalField waypointGeoIdHeightTxt = new BigDecimalField();
    private final BigDecimalField waypointAgeOfGPSDataTxt = new BigDecimalField();
    private final BigDecimalField waypointdGpsStationIdTxt = new BigDecimalField();
    private final ComboBox<String> waypointFixTxt = new ComboBox<>();
    private final BigDecimalField waypointHdopTxt = new BigDecimalField();
    private final BigDecimalField waypointVdopTxt = new BigDecimalField();
    private final BigDecimalField waypointPdopTxt = new BigDecimalField();
    private final BigDecimalField waypointMagneticVariationTxt = new BigDecimalField();
    private final BigDecimalField waypointSatTxt = new BigDecimalField();
    
    // TFE, 20181005: we also need our own decimalformat to have proper output
    private final DecimalFormat decimalFormat = new DecimalFormat("0");
    
    private List<GPXWaypoint> myGPXWaypoints;
    
    private EditGPXWaypoint() {
        super();
        // Exists only to defeat instantiation.
        
        decimalFormat.setMaximumFractionDigits(340); //340 = DecimalFormat.DOUBLE_FRACTION_DIGITS
        
        initViewer();
    }

    public static EditGPXWaypoint getInstance() {
        return INSTANCE;
    }

    private void initViewer() {
        // create new scene
        getStage().setTitle("Edit Waypoint Properties");
        getStage().initModality(Modality.APPLICATION_MODAL); 
        
        // https://de.wikipedia.org/wiki/GPS_Exchange_Format
        // http://www.topografix.com/gpx/1/1/
        //
        // What can be edited individually / for a list of waypoints?
        //
        // Name: xsd:string, individually
        // Sym: xsd:string, list of waypoints
        // Description: xsd:string, list of waypoints
        // Comment: xsd:string, list of waypoints
        // Time: xsd:dateTime, list of waypoints
        // Src: xsd:string, list of waypoints
        // Type: xsd:string, list of waypoints
        // Links: linkType, list of waypoints
        // Latitude: "%s %2d°%2d'%4.2f\"", individually
        // Longitude: "%s %2d°%2d'%4.2f\"", individually
        // Elevation: xsd:decimal , individually
        // GeoIdHeight: xsd:decimal , individually
        // Hdop: xsd:decimal , individually
        // Vdop: xsd:decimal , individually
        // Pdop: xsd:decimal , individually
        // Sat: xsd:nonNegativeInteger, individually
        // Fix: fixType, individually
        // MagneticVariation: xsd:decimal , individually
        // AgeOfGPSData: xsd:decimal , individually
        // dGpsStationId: dgpsStationType:integer, 0 <= value <= 1023, individually
        
        int rowNum = 0;
        // 1st row: name
        final Label nameLbl = new Label("Name:");
        getGridPane().add(nameLbl, 0, rowNum);
        GridPane.setMargin(nameLbl, INSET_TOP);

        getGridPane().add(waypointNameTxt, 1, rowNum, 3, 1);
        GridPane.setMargin(waypointNameTxt, INSET_TOP);
        
        rowNum++;
        // 2nd row: sym
        final Label symLbl = new Label("Symbol:");
        getGridPane().add(symLbl, 0, rowNum);
        GridPane.setMargin(symLbl, INSET_TOP);

        waypointSymTxt.setEditable(true);
        waypointSymTxt.setVisibleRowCount(10);
        // https://stackoverflow.com/a/58286816
//        <start>
        cboPersons.setConverter(new StringConverter<Person>() {
        @Override
        public String toString(Person person) {
            return person.getName();
        }

        @Override
        public Person fromString(String string) {
            return null;
        }
    });
//        <end>

    }

    public void setCallback(final GPXEditor gpxEditor) {
        myGPXEditor = gpxEditor;
    }
    
    public void editWaypoint(final List<GPXWaypoint> gpxWaypoints) {
        assert myGPXEditor != null;
        assert !CollectionUtils.isEmpty(gpxWaypoints);
        
        if (getStage().isShowing()) {
            getStage().close();
        }
        
        if (CollectionUtils.isEmpty(gpxWaypoints)) {
            return;
        }

        myGPXWaypoints = gpxWaypoints;
        
        initProperties();

        try {
            getStage().showAndWait();
            // TFE; 20200510: ugly hack!
            // when hiding the stage an update event is fired when the symbol of the waypoint has been changed
            // ComboBox tries to set to the text, when instead it shows labels =>
            // Exception in thread "JavaFX Application Thread" java.lang.ClassCastException: class java.lang.String cannot be cast to class javafx.scene.control.Label (java.lang.String is in module java.base of loader 'bootstrap'; javafx.scene.control.Label is in module javafx.controls of loader 'app')
        } catch (ClassCastException ex) {
        }
    }
    
    private void initProperties() {
        if (myGPXWaypoints.size() == 1) {
            initSingleProperties();
        } else {
            initMultipleProperties();
        }
    }
    
    private Label waypointSymbolLabelForText(final String labelText) {
        final Optional<Label> label = waypointSymTxt.getItems().stream().filter((t) -> {
            return t.getText().equals(labelText);
        }).findFirst();
        
        if (label.isPresent()) {
            return label.get();
        } else {
            return null;
        }
    }
    
    private void setWaypointSymTxt(final String labelText) {
        final Label label = waypointSymbolLabelForText(labelText);
        
        if (label != null) {
            waypointSymTxt.getSelectionModel().select(label);

            if (waypointSymTxt.getSkin() != null) {
                final ListView<Label> lv = ObjectsHelper.uncheckedCast(((ComboBoxListViewSkin) waypointSymTxt.getSkin()).getPopupContent());
                lv.scrollTo(waypointSymTxt.getSelectionModel().getSelectedIndex());
            }
        }
    }
    
    private void initSingleProperties() {
        final GPXWaypoint waypoint = myGPXWaypoints.get(0);
        
        waypointNameTxt.setText(setNullStringToEmpty(waypoint.getName()));
        setWaypointSymTxt(setNullStringToEmpty(waypoint.getSym()));
        waypointDescriptionTxt.setText(setNullStringToEmpty(waypoint.getDescription()));
        waypointCommentTxt.setText(setNullStringToEmpty(waypoint.getComment()));
        waypointTimeTxt.setText(setNullDateToEmpty(waypoint.getDate()));
        waypointSrcTxt.setText(setNullStringToEmpty(waypoint.getSrc()));
        waypointTypeTxt.setText(setNullStringToEmpty(waypoint.getWaypointType()));

        waypointLinkTable.getItems().clear();
        if (waypoint.getLinks() != null) {
            waypointLinkTable.getItems().addAll(waypoint.getLinks());
        }
        
        waypointLatitudeTxt.setDisable(false);
        waypointLatitudeTxt.setText(setNullStringToEmpty(LatLongHelper.latToString(waypoint.getLatitude())));
        waypointLongitudeTxt.setDisable(false);
        waypointLongitudeTxt.setText(setNullStringToEmpty(LatLongHelper.lonToString(waypoint.getLongitude())));

        waypointElevationTxt.setDisable(false);
        waypointElevationTxt.setText(setZeroToEmpty(waypoint.getElevation()));
        waypointGeoIdHeightTxt.setDisable(false);
        waypointGeoIdHeightTxt.setText(setZeroToEmpty(waypoint.getGeoIdHeight()));
        waypointHdopTxt.setDisable(false);
        waypointHdopTxt.setText(setZeroToEmpty(waypoint.getHdop()));
        waypointVdopTxt.setDisable(false);
        waypointVdopTxt.setText(setZeroToEmpty(waypoint.getVdop()));
        waypointPdopTxt.setDisable(false);
        waypointPdopTxt.setText(setZeroToEmpty(waypoint.getPdop()));
        waypointSatTxt.setDisable(false);
        waypointSatTxt.setText(setZeroToEmpty(waypoint.getSat()));
        waypointFixTxt.setDisable(false);
        if (waypoint.getFix() != null) {
            waypointFixTxt.setValue(setNullStringToEmpty(waypoint.getFix().toString()));
        } else {
            waypointFixTxt.setValue("");
        }
        waypointMagneticVariationTxt.setDisable(false);
        waypointMagneticVariationTxt.setText(setZeroToEmpty(waypoint.getMagneticVariation()));
        waypointAgeOfGPSDataTxt.setDisable(false);
        waypointAgeOfGPSDataTxt.setText(setZeroToEmpty(waypoint.getAgeOfGPSData()));
        waypointdGpsStationIdTxt.setDisable(false);
        waypointdGpsStationIdTxt.setText(setZeroToEmpty(waypoint.getdGpsStationId()));
    }
    
    private void initMultipleProperties() {
        final GPXWaypoint waypoint = myGPXWaypoints.get(0);
        
        waypointNameTxt.setText(MULTIPLE_VALUES);
        setWaypointSymTxt(setNullStringToEmpty(waypoint.getSym()));
        waypointDescriptionTxt.setText(MULTIPLE_VALUES);
        waypointCommentTxt.setText(MULTIPLE_VALUES);
        waypointTimeTxt.setText(MULTIPLE_VALUES);
        waypointSrcTxt.setText(MULTIPLE_VALUES);
        waypointTypeTxt.setText(MULTIPLE_VALUES);

        waypointLinkTable.getItems().clear();
        if (waypoint.getLinks() != null) {
            waypointLinkTable.getItems().addAll(waypoint.getLinks());
        }
        
        waypointLatitudeTxt.setDisable(true);
        waypointLatitudeTxt.setText(MULTIPLE_VALUES);
        waypointLongitudeTxt.setDisable(true);
        waypointLongitudeTxt.setText(MULTIPLE_VALUES);

        waypointElevationTxt.setDisable(true);
        waypointElevationTxt.setText(MULTIPLE_VALUES);
        waypointGeoIdHeightTxt.setDisable(true);
        waypointGeoIdHeightTxt.setText(MULTIPLE_VALUES);
        waypointHdopTxt.setDisable(true);
        waypointHdopTxt.setText(MULTIPLE_VALUES);
        waypointVdopTxt.setDisable(true);
        waypointVdopTxt.setText(MULTIPLE_VALUES);
        waypointPdopTxt.setDisable(true);
        waypointPdopTxt.setText(MULTIPLE_VALUES);
        waypointSatTxt.setDisable(true);
        waypointSatTxt.setText(MULTIPLE_VALUES);
        waypointFixTxt.setDisable(true);
        waypointFixTxt.setValue(MULTIPLE_VALUES);
        waypointMagneticVariationTxt.setDisable(true);
        waypointMagneticVariationTxt.setText(MULTIPLE_VALUES);
        waypointAgeOfGPSDataTxt.setDisable(true);
        waypointAgeOfGPSDataTxt.setText(MULTIPLE_VALUES);
        waypointdGpsStationIdTxt.setDisable(true);
        waypointdGpsStationIdTxt.setText(MULTIPLE_VALUES);
    }
    
    private void setProperties() {
        if (myGPXWaypoints.size() == 1) {
            setSingleProperties();
        } else {
            setMultipleProperties();
        }
    }
    
    private void setSingleProperties() {
        final GPXWaypoint waypoint = myGPXWaypoints.get(0);
        
        waypoint.setName(setEmptyToNullString(waypointNameTxt.getText()));
        waypoint.setSym(setEmptyToNullString(waypointSymTxt.getValue().getText()));
        waypoint.setDescription(setEmptyToNullString(waypointDescriptionTxt.getText()));
        waypoint.setComment(setEmptyToNullString(waypointCommentTxt.getText()));
        if (!waypointTimeTxt.getText().isEmpty()) {
            try {
                waypoint.setDate(GPXLineItem.DATE_FORMAT.parse(waypointTimeTxt.getText()));
            } catch (ParseException ex) {
                Logger.getLogger(EditGPXWaypoint.class.getName()).log(Level.SEVERE, null, ex);
                waypoint.setDate(null);
            }
        } else {
            waypoint.setDate(null);
        }
        waypoint.setSrc(setEmptyToNullString(waypointSrcTxt.getText()));
        waypoint.setWaypointType(setEmptyToNullString(waypointTypeTxt.getText()));

        if (!waypointLinkTable.getValidLinks().isEmpty()) {
            waypoint.setLinks(waypointLinkTable.getValidLinks().stream().collect(Collectors.toCollection(HashSet::new)));
        } else {
            waypoint.setLinks(null);
        }
        
        waypoint.setLatitude(LatLongHelper.latFromString(waypointLatitudeTxt.getText()));
        waypoint.setLongitude(LatLongHelper.lonFromString(waypointLongitudeTxt.getText()));

        waypoint.setElevation(setEmptyToZeroDouble(waypointElevationTxt.getText()));
        waypoint.setGeoIdHeight(setEmptyToZeroDouble(waypointGeoIdHeightTxt.getText()));
        waypoint.setHdop(setEmptyToZeroDouble(waypointHdopTxt.getText()));
        waypoint.setVdop(setEmptyToZeroDouble(waypointVdopTxt.getText()));
        waypoint.setPdop(setEmptyToZeroDouble(waypointPdopTxt.getText()));
        waypoint.setSat(setEmptyToZeroInt(waypointSatTxt.getText()));
        if (!waypointFixTxt.getValue().isEmpty()) {
            waypoint.setFix(Fix.returnType(waypointFixTxt.getValue()));
        } else {
            waypoint.setFix(null);
        }
        waypoint.setMagneticVariation(setEmptyToZeroDouble(waypointMagneticVariationTxt.getText()));
        waypoint.setAgeOfGPSData(setEmptyToZeroDouble(waypointAgeOfGPSDataTxt.getText()));
        waypoint.setdGpsStationId(setEmptyToZeroInt(waypointdGpsStationIdTxt.getText()));
    }
    
    private void setMultipleProperties() {
        // set only if different from MULTIPLE_VALUES or initial value
        
        final GPXWaypoint waypoint = myGPXWaypoints.get(0);
        
        if (!MULTIPLE_VALUES.equals(waypointNameTxt.getText())) {
            setMultipleStringValues(setEmptyToNullString(waypointNameTxt.getText()), GPXWaypoint::setName);
        }
        if ((waypoint.getSym() != null) && !waypoint.getSym().equals(waypointSymTxt.getValue().getText())) {
            setMultipleStringValues(setEmptyToNullString(waypointSymTxt.getValue().getText()), GPXWaypoint::setSym);
        }
        if (!MULTIPLE_VALUES.equals(waypointDescriptionTxt.getText())) {
            setMultipleStringValues(setEmptyToNullString(waypointDescriptionTxt.getText()), GPXWaypoint::setDescription);
        }
        if (!MULTIPLE_VALUES.equals(waypointCommentTxt.getText())) {
            setMultipleStringValues(setEmptyToNullString(waypointCommentTxt.getText()), GPXWaypoint::setComment);
        }
        if (!MULTIPLE_VALUES.equals(waypointTimeTxt.getText())) {
            Date date = null;
            if (!waypointTimeTxt.getText().isEmpty()) {
                try {
                    date = GPXLineItem.DATE_FORMAT.parse(waypointTimeTxt.getText());
                } catch (ParseException ex) {
                    Logger.getLogger(EditGPXWaypoint.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            setMultipleDateValues(date, GPXWaypoint::setDate);
        }
        if (!MULTIPLE_VALUES.equals(waypointSrcTxt.getText())) {
            setMultipleStringValues(setEmptyToNullString(waypointSrcTxt.getText()), GPXWaypoint::setSrc);
        }
        if (!MULTIPLE_VALUES.equals(waypointTypeTxt.getText())) {
            setMultipleStringValues(setEmptyToNullString(waypointTypeTxt.getText()), GPXWaypoint::setWaypointType);
        }
        if (!waypointLinkTable.getValidLinks().isEmpty()) {
            setMultipleLinkValues(waypointLinkTable.getValidLinks().stream().collect(Collectors.toCollection(HashSet::new)), GPXWaypoint::setLinks);
        } else {
            setMultipleLinkValues(null, GPXWaypoint::setLinks);
        }
    }
    
    // don't call alle the different setters in individual streams
    private void setMultipleStringValues(final String newValue, final BiConsumer<GPXWaypoint, String> setter) {
        myGPXWaypoints.stream().forEach((t) -> {
            setter.accept(t, newValue);
        });
    }
    
    // don't call alle the different setters in individual streams
    private void setMultipleDateValues(final Date newValue, final BiConsumer<GPXWaypoint, Date> setter) {
        myGPXWaypoints.stream().forEach((t) -> {
            setter.accept(t, newValue);
        });
    }
    
    // don't call alle the different setters in individual streams
    private void setMultipleLinkValues(final HashSet<Link> newValue, final BiConsumer<GPXWaypoint, HashSet<Link>> setter) {
        myGPXWaypoints.stream().forEach((t) -> {
            setter.accept(t, newValue);
        });
    }
    
    private String setZeroToEmpty(final int test) {
        String result = "";
        
        result = Integer.toString(test);

        return result;
    }
    
    private String setZeroToEmpty(final double test) {
        String result = "";
        
        result = decimalFormat.format(test);

        return result;
    }
    
    private String setNullStringToEmpty(final String test) {
        String result = "";
        
        if (!StringUtils.isEmpty(test)) {
            result = test;
        }

        return result;
    }
    
    private String setNullDateToEmpty(final Date test) {
        String result = "";
        
        if (test != null) {
            result = GPXLineItem.DATE_FORMAT.format(test);
        }

        return result;
    }
    
    private String setEmptyToNullString(final String test) {
        String result = null;
        
        if (!StringUtils.isEmpty(test)) {
            result = test;
        }

        return result;
    }
    
    private int setEmptyToZeroInt(final String test) {
        int result = 0;
        
        if (!StringUtils.isEmpty(test)) {
            result = Integer.valueOf(test);
        }

        return result;
    }
    
    private double setEmptyToZeroDouble(final String test) {
        double result = 0.0;
        
        if (!StringUtils.isEmpty(test)) {
            try {
                result = NumberFormat.getNumberInstance().parse(test.trim()).doubleValue();
            } catch (ParseException ex) {
                Logger.getLogger(EditGPXWaypoint.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return result;
    }
}
